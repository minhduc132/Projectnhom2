﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WcfServiceLibrary2
{
    public class Type
    {
        public string Id { get; set; }
        public int Ratio { get; set; }
    }
}
